#include <pthread.h>
#include <stdatomic.h>
#include <assert.h>
#include <stdio.h>
#include <inttypes.h>

atomic_int entering[2] = {0, 0};
atomic_int turn = 0;

#define RELAXED 1

#if RELAXED
#define order memory_order_relaxed
#else
#define order memory_order_seq_cst
#endif

#define store(A, V) atomic_store_explicit(A, V, order)
#define load(A) atomic_load_explicit(A, order)

// Dekker's algorithm see Wikipedia: https://en.wikipedia.org/wiki/Dekker%27s_algorithm
// Notorious for breaking on modern hardware including Intel TSO.
void lock(int me) {
  store(&entering[me], 1);
  while (load(&entering[1-me])) {
    if (load(&turn) != me) {
      store(&entering[me], 0);
      while (load(&turn) != me) {
        // busy wait
      }
      store(&entering[me], 1);
    }
  }
}

void unlock(int me) {
  store(&turn, 1-me);
  store(&entering[me], 0);
}

int i = 0;
const int n = 10000000;

int run(void* mep) {
  int me = (uintptr_t) mep;
  int j = n;
  while (j-- > 0) {
    lock(me);
    i++;
    unlock(me);
  }
  return 0;
}

int main() {
  pthread_t t;
  int r = pthread_create(&t, NULL, run, (void*) 1);
  assert(r == 0);

  run((void*) 0);

  pthread_join(t, NULL);

  printf("i %d\n", i);

  return 0;
}