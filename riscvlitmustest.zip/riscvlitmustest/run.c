#include <stdlib.h>
#include <stdio.h>

/* Declarations of tests entry points */
extern int ISA_2D_DEP_2D_ADDR(int argc,char **argv,FILE *out);
extern int _X2_2B_2W_2B_poss(int argc,char **argv,FILE *out);
extern int C_2D_Will02_2B_HEAD(int argc,char **argv,FILE *out);
extern int MP_2B_po_2B_poaqp(int argc,char **argv,FILE *out);
extern int _X2_2B_2Swap_2B_Acqs(int argc,char **argv,FILE *out);
extern int _X2_2B_2W(int argc,char **argv,FILE *out);
extern int _X2_2B_2W_2B_fence_2E_i_2B_fence_2E_rw_2E_rw(int argc,char **argv,FILE *out);
extern int _X2_2B_2W_2B_fence_2E_tsos(int argc,char **argv,FILE *out);
extern int RSW(int argc,char **argv,FILE *out);
extern int ISA01(int argc,char **argv,FILE *out);
extern int ISA02(int argc,char **argv,FILE *out);
extern int ISA09(int argc,char **argv,FILE *out);
extern int PPOAA(int argc,char **argv,FILE *out);
extern int PPOCA(int argc,char **argv,FILE *out);
extern int PPODA(int argc,char **argv,FILE *out);
extern int ForwardSc(int argc,char **argv,FILE *out);
extern int ForwardAMO(int argc,char **argv,FILE *out);
extern int CoWR(int argc,char **argv,FILE *out);
extern int CoRR(int argc,char **argv,FILE *out);
extern int CoRW2(int argc,char **argv,FILE *out);
extern int CoWR0(int argc,char **argv,FILE *out);
extern int CoWW(int argc,char **argv,FILE *out);
extern int SB(int argc,char **argv,FILE *out);
extern int MP(int argc,char **argv,FILE *out);
extern int AMO_2D_FENCE(int argc,char **argv,FILE *out);
extern int CO_2D_SBI(int argc,char **argv,FILE *out);
extern int ISA_2D_DEP_2D_ADDR(int argc,char **argv,FILE *out);
extern int ISA_2D_DEP_2D_CTRL(int argc,char **argv,FILE *out);
extern int ISA_2D_DEP_2D_SUCCESS(int argc,char **argv,FILE *out);
extern int ISA_2D_DEP_2D_WR_2D_ADDR(int argc,char **argv,FILE *out);
extern int ISA_2D_DEP_2D_WW_2D_DATA(int argc,char **argv,FILE *out);
extern int LB(int argc,char **argv,FILE *out);
extern int LB_2B_addr_2B_addr_2D_fri_2D_rfi_2D_addr(int argc,char **argv,FILE *out);
extern int LB_2B_ctrl_2B_po(int argc,char **argv,FILE *out);
extern int LB_2B_fence_2E_w_2E_ws(int argc,char **argv,FILE *out);
extern int LR_2D_SC_2D_diff_2D_loc1(int argc,char **argv,FILE *out);
extern int LR_2D_SC_2D_diff_2D_loc2(int argc,char **argv,FILE *out);
extern int LR_2D_SC_2D_diff_2D_loc3(int argc,char **argv,FILE *out);
extern int LR_2D_SC_2D_diff_2D_loc4(int argc,char **argv,FILE *out);
extern int LR_2D_SC_2D_NOT_2D_FENCE(int argc,char **argv,FILE *out);
extern int MP_2B_fence_2E_rw_2E_ws(int argc,char **argv,FILE *out);
extern int MP_2B_porlp_2B_po(int argc,char **argv,FILE *out);
extern int MP_2B_poss(int argc,char **argv,FILE *out);
extern int _S(int argc,char **argv,FILE *out);
extern int _R(int argc,char **argv,FILE *out);
extern int R_2B_fence_2E_rw_2E_ws(int argc,char **argv,FILE *out);
extern int R_2B_poss(int argc,char **argv,FILE *out);
extern int RSW_2B_W(int argc,char **argv,FILE *out);
extern int S_2B_fence_2E_w_2E_ws(int argc,char **argv,FILE *out);
extern int SB_2B_fence_2E_is(int argc,char **argv,FILE *out);
extern int SB_2B_fence_2E_i_2B_fence_2E_rw_2E_rw(int argc,char **argv,FILE *out);
extern int SB_2B_fence_2E_r_2E_rws(int argc,char **argv,FILE *out);
extern int SB_2B_fence_2E_r_2E_rw_2B_fence_2E_rw_2E_rw(int argc,char **argv,FILE *out);
extern int SB_2B_popaq_2B_poprl_2D_porlaq_2D_posaqp(int argc,char **argv,FILE *out);
extern int SB_2B_popaq_2B_porlaq(int argc,char **argv,FILE *out);
extern int SB_2B_popaq_2B_porlp(int argc,char **argv,FILE *out);
extern int SB_2B_popaq_2B_pos_2D_popaq(int argc,char **argv,FILE *out);
extern int SB_2B_poprl_2D_porlp_2B_posprl_2D_porlp_2D_addr(int argc,char **argv,FILE *out);
extern int SB_2B_pos_2D_pos_2D_addrs(int argc,char **argv,FILE *out);
extern int SB_2B_poss(int argc,char **argv,FILE *out);
extern int SC_2D_FAIL(int argc,char **argv,FILE *out);
extern int SWAP_2D_LR_2D_SC(int argc,char **argv,FILE *out);
extern int SWAP_2D_LR_2D_SC_2B_FULL(int argc,char **argv,FILE *out);
extern int Luc02(int argc,char **argv,FILE *out);
extern int Luc03(int argc,char **argv,FILE *out);
extern int Luc02_2B_BIS(int argc,char **argv,FILE *out);
extern int Luc03_2B_BIS(int argc,char **argv,FILE *out);
extern int MP_2B_fence_2E_w_2E_w_2B_fri_2D_rfi_2D_ctrlfencei(int argc,char **argv,FILE *out);
extern int R_2B_fence_2E_i_2B_fence_2E_rw_2E_rw(int argc,char **argv,FILE *out);
extern int R_2B_fence_2E_r_2E_rw_2B_fence_2E_rw_2E_rw(int argc,char **argv,FILE *out);
extern int R_2B_fence_2E_rw_2E_rw_2B_fence_2E_i(int argc,char **argv,FILE *out);
extern int R_2B_fence_2E_rw_2E_rw_2B_fence_2E_r_2E_rw(int argc,char **argv,FILE *out);
extern int R_2B_fence_2E_rw_2E_rw_2B_fence_2E_rw_2E_w(int argc,char **argv,FILE *out);
extern int R_2B_fence_2E_rw_2E_rw_2B_fence_2E_w_2E_w(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_fence_2E_r_2E_rw(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_fence_2E_rw_2E_w(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_fence_2E_rw_2E_rw(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_addr(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_data(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_ctrl(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_ctrlfencei(int argc,char **argv,FILE *out);
extern int S_2B_po_2B_poaqp(int argc,char **argv,FILE *out);


/* Date function */
#include <time.h>
static void my_date(FILE *out) {
  time_t t = time(NULL);
  fprintf(out,"%s",ctime(&t));
}

/* Postlude */
static void end_report(int argc,char **argv,FILE *out) {
  fprintf(out,"%s\n","Revision exported, version 7.56+03");
  fprintf(out,"%s\n","Command line: litmus7 -mach ./riscv.cfg -avail 2 -excl instructions.excl -o hw-tests-src tests/non-mixed-size/@all");
  fprintf(out,"%s\n","Parameters");
  fprintf(out,"%s\n","#define SIZE_OF_TEST 100");
  fprintf(out,"%s\n","#define NUMBER_OF_RUN 10");
  fprintf(out,"%s\n","#define AVAIL 2");
  fprintf(out,"%s\n","#define STRIDE 1");
  fprintf(out,"%s\n","#define MAX_LOOP 0");
  fprintf(out,"%s\n","/* gcc options: -D_GNU_SOURCE -DFORCE_AFFINITY -Wall -std=gnu99 -O2 -pthread */");
  fprintf(out,"%s\n","/* gcc link options: -static */");
  fprintf(out,"%s\n","/* barrier: userfence */");
  fprintf(out,"%s\n","/* launch: changing */");
  fprintf(out,"%s\n","/* affinity: incr1 */");
  fprintf(out,"%s\n","/* memory: direct */");
  fprintf(out,"%s\n","/* stride: 1 */");
  fprintf(out,"%s\n","/* safer: write */");
  fprintf(out,"%s\n","/* preload: random */");
  fprintf(out,"%s\n","/* speedcheck: no */");
  fprintf(out,"%s\n","/* alloc: dynamic */");
  fprintf(out,"%s\n","/* proc used: 2 */");
/* Command line options */
  fprintf(out,"%s","Command:");
  for ( ; *argv ; argv++) {
    fprintf(out," %s",*argv);
  }
  fprintf(out,"%s","\n");
}

/* Run all tests */
static void run(int argc,char **argv,FILE *out) {
  my_date(out);
  ISA_2D_DEP_2D_ADDR(argc,argv,out);
  _X2_2B_2W_2B_poss(argc,argv,out);
  C_2D_Will02_2B_HEAD(argc,argv,out);
  MP_2B_po_2B_poaqp(argc,argv,out);

_X2_2B_2Swap_2B_Acqs(argc,argv,out);
_X2_2B_2W(argc,argv,out);
_X2_2B_2W_2B_fence_2E_i_2B_fence_2E_rw_2E_rw(argc,argv,out);
_X2_2B_2W_2B_fence_2E_tsos(argc,argv,out);
RSW(argc,argv,out);
ISA01(argc,argv,out);
ISA02(argc,argv,out);
ISA09(argc,argv,out);
PPOAA(argc,argv,out);
PPOCA(argc,argv,out);
PPODA(argc,argv,out);
ForwardSc(argc,argv,out);
ForwardAMO(argc,argv,out);
CoWR(argc,argv,out);
CoRR(argc,argv,out);
CoRW2(argc,argv,out);
CoWR0(argc,argv,out);
CoWW(argc,argv,out);
SB(argc,argv,out);
MP(argc,argv,out);
AMO_2D_FENCE(argc,argv,out);
CO_2D_SBI(argc,argv,out);
ISA_2D_DEP_2D_ADDR(argc,argv,out);
ISA_2D_DEP_2D_CTRL(argc,argv,out);
ISA_2D_DEP_2D_SUCCESS(argc,argv,out);
ISA_2D_DEP_2D_WR_2D_ADDR(argc,argv,out);
ISA_2D_DEP_2D_WW_2D_DATA(argc,argv,out);
LB(argc,argv,out);
LB_2B_addr_2B_addr_2D_fri_2D_rfi_2D_addr(argc,argv,out);
LB_2B_ctrl_2B_po(argc,argv,out);
LB_2B_fence_2E_w_2E_ws(argc,argv,out);
LR_2D_SC_2D_diff_2D_loc1(argc,argv,out);
LR_2D_SC_2D_diff_2D_loc2(argc,argv,out);
LR_2D_SC_2D_diff_2D_loc3(argc,argv,out);
LR_2D_SC_2D_diff_2D_loc4(argc,argv,out);
LR_2D_SC_2D_NOT_2D_FENCE(argc,argv,out);
MP_2B_fence_2E_rw_2E_ws(argc,argv,out);
MP_2B_porlp_2B_po(argc,argv,out);
MP_2B_poss(argc,argv,out);
_S(argc,argv,out);
_R(argc,argv,out);
R_2B_fence_2E_rw_2E_ws(argc,argv,out);
R_2B_poss(argc,argv,out);
RSW_2B_W(argc,argv,out);
S_2B_fence_2E_w_2E_ws(argc,argv,out);
SB_2B_fence_2E_is(argc,argv,out);
SB_2B_fence_2E_i_2B_fence_2E_rw_2E_rw(argc,argv,out);
SB_2B_fence_2E_r_2E_rws(argc,argv,out);
SB_2B_fence_2E_r_2E_rw_2B_fence_2E_rw_2E_rw(argc,argv,out);
SB_2B_popaq_2B_poprl_2D_porlaq_2D_posaqp(argc,argv,out);
SB_2B_popaq_2B_porlaq(argc,argv,out);
SB_2B_popaq_2B_porlp(argc,argv,out);
SB_2B_popaq_2B_pos_2D_popaq(argc,argv,out);
SB_2B_poprl_2D_porlp_2B_posprl_2D_porlp_2D_addr(argc,argv,out);
SB_2B_pos_2D_pos_2D_addrs(argc,argv,out);
SB_2B_poss(argc,argv,out);
SC_2D_FAIL(argc,argv,out);
SWAP_2D_LR_2D_SC(argc,argv,out);
SWAP_2D_LR_2D_SC_2B_FULL(argc,argv,out);
Luc02(argc,argv,out);
Luc03(argc,argv,out);
Luc02_2B_BIS(argc,argv,out);
Luc03_2B_BIS(argc,argv,out);
MP_2B_fence_2E_w_2E_w_2B_fri_2D_rfi_2D_ctrlfencei(argc,argv,out);
R_2B_fence_2E_i_2B_fence_2E_rw_2E_rw(argc,argv,out);
R_2B_fence_2E_r_2E_rw_2B_fence_2E_rw_2E_rw(argc,argv,out);
R_2B_fence_2E_rw_2E_rw_2B_fence_2E_i(argc,argv,out);
R_2B_fence_2E_rw_2E_rw_2B_fence_2E_r_2E_rw(argc,argv,out);
R_2B_fence_2E_rw_2E_rw_2B_fence_2E_rw_2E_w(argc,argv,out);
R_2B_fence_2E_rw_2E_rw_2B_fence_2E_w_2E_w(argc,argv,out);
S_2B_po_2B_fence_2E_r_2E_rw(argc,argv,out);
S_2B_po_2B_fence_2E_rw_2E_w(argc,argv,out);
S_2B_po_2B_fence_2E_rw_2E_rw(argc,argv,out);
S_2B_po_2B_addr(argc,argv,out);
S_2B_po_2B_data(argc,argv,out);
S_2B_po_2B_ctrl(argc,argv,out);
S_2B_po_2B_ctrlfencei(argc,argv,out);
S_2B_po_2B_poaqp(argc,argv,out);
  
  end_report(argc,argv,out);
  my_date(out);
}

int main(int argc,char **argv) {
  run(argc,argv,stdout);
  return 0;
}
