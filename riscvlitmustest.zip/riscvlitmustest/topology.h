/* Topologies for threads in {1,2} */

extern const int *inst_1;
extern const int *role_1;
extern const char **group_1;
#define scansz_1 1
#define scanline_1 2

extern const int *inst_2;
extern const int *role_2;
extern const char **group_2;
#define scansz_2 1
#define scanline_2 2
