/* Topologies for threads in {1,2} */

/***************/
/* nthreads=1 */
/***************/

/*
 Topology: {{{0, 1}}}
*/

static const int _inst_1[] = {
// [[0]]
0, 1,
};

const int *inst_1 = &_inst_1[0];

static const int _role_1[] = {
// [[0]]
0, 0,
};

const int *role_1 = &_role_1[0];

static const char *_group_1[] = {
"[[0]]",
};

const char **group_1 = &_group_1[0];



/***************/
/* nthreads=2 */
/***************/

/*
 Topology: {{{0, 1}}}
*/

static const int _inst_2[] = {
// [[0,1]]
0, 0,
};

const int *inst_2 = &_inst_2[0];

static const int _role_2[] = {
// [[0,1]]
0, 1,
};

const int *role_2 = &_role_2[0];

static const char *_group_2[] = {
"[[0,1]]",
};

const char **group_2 = &_group_2[0];


